let nota1 = 10;
let nota2 = 7;
let nota3 = 9;
let p1 = 2;
let p2 = 3;
let p3 = 5;

let media = (nota1 * p1 + nota2 * p2 + nota2 * p3) / (p1 + p2 + p3);

console.log(media);
